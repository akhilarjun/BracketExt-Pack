/*
* Author : Akhil Arjun
* visit me : http://www.akhilarjun.com
*/
define(function (require, exports, module) {
    "use strict";
    var CommandManager  = brackets.getModule("command/CommandManager"),
		EditorManager   = brackets.getModule("editor/EditorManager"),
		DocumentManager = brackets.getModule("document/DocumentManager"),
		Menus           = brackets.getModule("command/Menus"),
		COMMAND_ID      = "akhil.html5WithAngular1.4.template";

    // Enable template generation plugin
    CommandManager.register("HTML5 + AngularJS Template", COMMAND_ID, renderHTML5Template);
    function renderHTML5Template() {
        var editor = EditorManager.getFocusedEditor();
        if (!editor) {
            return;
        }
        var insertionPos = editor.getCursorPos();
        editor.document.replaceRange('<!DOCTYPE html>\n <html>\n <head>\n <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">\n <link rel="icon" href="favicon.ico" type="image/x-icon" />\n <meta charset="utf-8">\n <meta http-equiv="X-UA-Compatible" content="IE=edge">\n <meta name="viewport" content="width=device-width,initial-scale=1">\n </head>\n <body>\n <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>\n <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.0/angular.min.js"></script>\n <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.0/angular-animate.min.js"></script>\n </body>\n </html>', insertionPos);
		//Thanks Vaibhav -- http://vaibhavtiwari.co.in
		var doc = editor._codeMirror;
        for (var i = 0, n = doc.lineCount(); i < n; i++) {
            doc.indentLine(i);
        }
    }
    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuItem(COMMAND_ID, [{key: "Ctrl-shift-T", platform: "win"},
                                  {key: "Cmd-shift-T", platform: "mac"}]);
    
});
